# 0x16-simple_shell
Write a simple UNIX command interpreter.
