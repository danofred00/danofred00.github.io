
	***********************************
	**    PATCHED BY @Danofred00     **
	**     danofred00@gmail.com      **
	** https://github.com/danofred00 **
	***********************************

Download link : https://danofred00.github.com/re/plcvn_by_Danofred00.zip

If you get this error message, "msvbvm60.dll is missing", fix it with this :
 -> copy msvbvm60.dll to C:/Windows/System32 directory
